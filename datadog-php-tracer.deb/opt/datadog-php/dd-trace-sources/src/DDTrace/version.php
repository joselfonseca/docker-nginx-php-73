<?php

return '0.29.0'; // Update Tracer::VERSION too
